using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace program.Pages  
{  
    public class StationInfoModel : PageModel  
    {  
				public List<Models.Station> StationList { get; set; }
				public string Input { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  StationList = new List<Models.Station>();
					
					// make input available to web page:
					Input = input;
					
					// clear exception:
					EX = null;
					
					try
					{
						//
						// Do we have an input argument?  If not, there's nothing to do:
						//
						if (input == null)
						{
							//
							// there's no page argument, perhaps user surfed to the page directly?  
							// In this case, nothing to do.
							//
						}
						else  
						{

							string sql;

						  // lookup station(s) by partial name match:
							input = input.Replace("'", "''");

							sql = string.Format(@"
                            SELECT Stations.StationID, Stations.Name, 
                            AVG(DailyTotal) AS AvgDailyRidership,
                            (COUNT (distinct Stops.StopID)) AS NumStops, 
                            (Sum(convert(int, ADA))/6514) AS HandicapAcessible
                            FROM Stations
                            LEFT JOIN Riderships ON Stations.StationID = Riderships.StationID
                            LEFT JOIN Stops ON Stations.StationID = Stops.StationID
                            WHERE Stations.Name LIKE '%{0}%'
                            GROUP BY Stations.StationID, Stations.Name
                            ORDER BY Stations.Name ASC;", input);

                    DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        Models.Station s = new Models.Station();

                        s.StationID = Convert.ToInt32(row["StationID"]);
                        s.StationName = Convert.ToString(row["Name"]);

                        // avg could be null if there is no ridership data:
                        if (row["AvgDailyRidership"] == System.DBNull.Value)
                            s.AvgDailyRidership = 0;
                        else
                            s.AvgDailyRidership = Convert.ToInt32(row["AvgDailyRidership"]);


                        if (row["HandicapAcessible"] == System.DBNull.Value)
                        {
                            s.HandicapCount = 0;
                        }
                        else
                        {
                            s.HandicapCount = Convert.ToInt32(row["HandicapAcessible"]);
                        }

                        s.NumStops = Convert.ToInt32(row["NumStops"]);
                        //s.HandicapCount = Convert.ToInt32(row["HandicapAcessible"]);



                        if (s.HandicapCount == 0)
                        {
                            s.HandyAccess = Convert.ToString(row["HandicapAcessible"]);
                            s.HandyAccess = "none";
                        }

                        if (s.HandicapCount == s.NumStops)
                        {
                            s.HandyAccess = Convert.ToString(row["HandicapAcessible"]);
                            s.HandyAccess = "all";
                        }
                        else
                        {
                            s.HandyAccess = "some"; 
                        }


                        StationList.Add(s);
                    }
                }//else
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  // nothing at the moment
				  }
				}
			
    }//class  
}//namespace